function myFunction() {
    if(confirm("we have detected that you dont have an account with us, please create one to use our services") ==true){
      window.location.replace("./signin.html")
    }
  }
  function myFunction1() {
    if(confirm("Should we confirm your request") ==true){
      window.location.replace("./index.html")
      alert("Your request has been successfully recorded")
      
    }
  }
  function myFunction2() {
    location.reload()
    }
  
  function myFunction3() {
    if(confirm("Do you want to access the code behind website?") ==true){
      window.open('https://github.com/Aditya-Bhadauria  ','_blank')
      
        
    }
  }
  function myFunction4() {
    alert("we are a team of students who were tasked to create this website 1)Aditya Bhadauria(12208458) \n 2)Mayank Gahlot(12211318) \n 3)Samaira Katoch(12210856)")
  }
  function myFunction5() {
    alert("All the feedback must be submitted to github,Click on accessibility to access the github profile")
  }
  function myFunction6() {
    alert("All the information about the devs can be found on their respective 'Linkdin profiles'")
  }
  
